package fooddeliveryrevival;

import fooddeliveryrevival.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler {

    @Autowired
    OrderRepository orderRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrderPlaced_NotifyOrder(@Payload OrderPlaced orderPlaced){

        if(orderPlaced.isMe()){
            Order order = new Order();
            order.setOrderId(orderPlaced.getId());
            order.setProductId(orderPlaced.getProductId());
            System.out.println("##### listener NotifyOrder : " + orderPlaced.toJson());
            orderRepository.save(order);
        }
    }
}

